# MyProjects-PHP-
First project on php
Type of e-comm site for one vendor and multiple buyers.Buyers can req to buy one product at a time and if he wants to by more than one than he has to req again for buying and vendor can accept or decline request.


admin credentials: 


  username:namansngh64      
  password:naman  
NOTE:-You will have to import the attached sql file for this to work!
Also some functions like mail() was not working in xampp for some reason so in otp verification,the otp is by default entered in the text field. 

